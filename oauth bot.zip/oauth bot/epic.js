const { ActivityType, PresenceUpdateStatus } = require("discord.js");
module.exports = {
  client_id: "client id", // client id ",
  client_secret: "client secret", // bot secret
  redirect_uri: "redirect url", //redirect url
  mainserver: "https://discord.gg/",
  footer: "C1baby", //you can change it 
  support: "C1baby", //not required
  backupchannelid: "bacjyp auth channel ids", // channel for auth to backup to 
  statuschannel: {
    userhookurl: "webhook url", // new auth log
    serverhookurl: "url webhook", //new server log
    enabled: false, //dum thing that spams ur webhook 
    interval: 6000 // intravel to spam thte user and server stats
  },
  emojis: {
    already: "`❌`",
    deleted: "`❌`",
    dot: "",
    error: "`☢`",
    limitusers: "`🚫v",
    msg: "`⏰`",
    onlineusers: "`✅`",
    progress: "",
    succes: "`✅`",
    unsucces: "`❌`",
    hehe: "`🤼‍♂️`",
    users: "`🤼‍♂️`",
  },
  owners: ["ids to wl" , "" , "" , "" , ""], //example for multiple ids ["owenr_1_id", "owner_2_id"])
  token: "",
  webhooks: {
    general: "webhook url",
    join: "webhook url",
    //debug:""
  },
  durum: "Best Multi Bot",
  type: ActivityType.Playing,
  status: PresenceUpdateStatus.Idle,
}
//nigga epic fr